window.boot = function () {
    var settings = window._CCSettings;
    window._CCSettings = undefined;

    var RESOURCES = cc.AssetManager.BuiltinBundleName.RESOURCES;
    var INTERNAL = cc.AssetManager.BuiltinBundleName.INTERNAL;
    var MAIN = cc.AssetManager.BuiltinBundleName.MAIN;

    var onStart = function () {
        cc.view.enableRetina(true);
        cc.view.resizeWithBrowserSize(true);

        var launchScene = settings.launchScene;
        var bundle = cc.assetManager.bundles.find(function (b) {
            return b.getSceneInfo(launchScene);
        });

        bundle.loadScene(launchScene, null, null, function (err, scene) {
            if (!err) {
                cc.director.runSceneImmediate(scene);
            }
        });
    };

    var option = {
        id: 'GameCanvas',
        debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
        showFPS: settings.debug,
        frameRate: 60,
        groupList: settings.groupList,
        collisionMatrix: settings.collisionMatrix,
    };

    cc.assetManager.init({
        bundleVers: settings.bundleVers,
        remoteBundles: settings.remoteBundles,
        server: settings.server
    });

    var bundleRoot = [INTERNAL];
    settings.hasResourcesBundle && bundleRoot.push(RESOURCES);

    var count = 0;
    function cb(err) {
        if (err) return console.error(err.message, err.stack);
        count++;
        if (count === bundleRoot.length + 1) {
            cc.assetManager.loadBundle(MAIN, function (err) {
                if (!err) cc.game.run(option, onStart);
            });
        }
    }

    cc.assetManager.loadScript(settings.jsList.map(function (x) { return 'src/' + x; }), cb);

    for (var i = 0; i < bundleRoot.length; i++) {
        cc.assetManager.loadBundle(bundleRoot[i], cb);
    }
};

if (window.jsb) {
    //wecustom start
    var searchPathsStr = localStorage.getItem('cache_search_paths');
    if (searchPathsStr) {
        try {
            var searchPaths = JSON.parse(searchPathsStr);
            jsb.fileUtils.setSearchPaths(searchPaths);
        } catch (err) {
            console.error(`wecustom searchPaths parse, searchPathsStr: ${searchPathsStr}, err: ${JSON.stringify(err.message || err)}`);
        }
    }

    var basePathExist = false;
    var searchPaths = jsb.fileUtils.getSearchPaths();
    for (var i = 0; i < searchPaths.length; i++) {
        if (searchPaths[i].indexOf('assets/assets/') != -1) {
            basePathExist = true;
            break;
        }
    }
    if (!basePathExist) {
        jsb.fileUtils.setSearchPaths(['assets/assets/', 'assets/'].concat(searchPaths));
    }

    var coverInstall = localStorage.getItem('app_cover_install');
    if (coverInstall == '1') {
        localStorage.removeItem('app_cover_install');
        jsb.fileUtils.removeDirectory(jsb.fileUtils.getWritablePath() + 'assets/assets/');
        jsb.fileUtils.setSearchPaths(['assets/assets/', 'assets/']);
    }
    console.log(`wecustom searchPaths: ${JSON.stringify(jsb.fileUtils.getSearchPaths())}`);
    //wecustom end

    var isRuntime = (typeof loadRuntime === 'function');
    if (isRuntime) {
        require('assets/assets/src/settings.js');
        require('assets/assets/src/cocos2d-runtime.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('assets/assets/src/physics.js');
        }
        require('jsb-adapter/engine/index.js');
    } else {
        require('assets/assets/src/settings.js');
        require('assets/assets/src/cocos2d-jsb.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('assets/assets/src/physics.js');
        }
        require('jsb-adapter/jsb-engine.js');
    }

    cc.macro.CLEANUP_IMAGE_CACHE = true;
    window.boot();
}
